---
def: http://example.org/todo/create
rel: http://example.org/todo/create create create-form
type: unsafe
rt: "#todoItem"
---

Transition to create a new TODO Item

SHOULD see a series of HREF descriptors as children, but not sure how to do that.
