---
id: status-enum
def: http://example.org/defs/status-enum
rel: http://example.org/rels/status-enum collection
href: http://example.org/docs/status-enum.html
value: "closed,open,pending"
---

List of valid status values
