---
def: 
rel:
name: filter
rt: "#todoItem"
type: safe
---

Returns a filtered list of TODO items.

Supports filter by title (alpha) and status (open/closed).
