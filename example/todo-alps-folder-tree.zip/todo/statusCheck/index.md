---
id: statusCheck
name: statusCheck
def: http://examples.org/defs/status-check
rel: http://examples.org/defs/status-check collection
type: safe
rt: "#statusCheck"
title: displays realtime status of TODO collection
----
Displays realtime status of TODO collection
