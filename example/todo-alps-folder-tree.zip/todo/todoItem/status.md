---
def: https://schema.org/status
name: status
---

Status of the todoItem
