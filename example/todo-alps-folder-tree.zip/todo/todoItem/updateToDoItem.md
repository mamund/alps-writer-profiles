---
def: http://example.org/update
rel: http://example.org/update
name: update
rt: "#todoItem"
type: idempotent
---

Transition to update an existing TODO Item.
