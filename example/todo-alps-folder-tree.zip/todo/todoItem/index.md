---
name: todoItem
id: todoItem
---

This is a group of properties for a single todoItem
