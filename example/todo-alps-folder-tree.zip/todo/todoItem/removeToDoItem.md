---
def: http://example.org/todo/remove
rel: http://example.org/todo/remove
name: remove
rt: "#todoItem"
type: idempotent
tag: delete
---

Removes an existing TODO Item from the collection
